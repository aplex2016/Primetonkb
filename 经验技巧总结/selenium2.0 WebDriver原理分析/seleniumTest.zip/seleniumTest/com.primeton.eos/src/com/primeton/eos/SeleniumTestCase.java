/*********************************************
 * Copyright (c) 2010 primeton.
 * All rights reserved.
 * Created on 2013-3-3 ����07:07:11

 * Contributors:
 *     ccq - initial implementation
 *********************************************/

package com.primeton.eos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverBackedSelenium;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.thoughtworks.selenium.Selenium;

public class SeleniumTestCase {
	
	
	
	public static void main(String[] args) {
		//�������������
		WebDriver driver = new InternetExplorerDriver();
		//��governorҳ��
		driver.get("http://127.0.0.1:8080/eos-governor/governor/user/login.jsp");
		//������ֵ
		driver.findElement(By.name("userName")).sendKeys("sysadmin");
		driver.findElement(By.name("password")).sendKeys("000000");	
		//�����¼��ť
		driver.findElement(By.xpath("//input[@value='��¼']")).click();
	}

}

/*
 * �޸���ʷ
 * $Log$ 
 */