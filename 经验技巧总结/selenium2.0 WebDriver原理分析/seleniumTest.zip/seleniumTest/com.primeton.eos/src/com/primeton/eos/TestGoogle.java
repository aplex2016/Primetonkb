package com.primeton.eos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class TestGoogle {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DesiredCapabilities capability=DesiredCapabilities.firefox();
		capability.setCapability("firefox_binary","D:/Program Files (x86)/huohu/Mozilla Firefox/firefox.exe");
        WebDriver driver = new FirefoxDriver(capability);
		driver.get("http://google.com");

	}

}
